package day3Loop_for_while_case;

public class StringInSwitch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String name = "Fullname";  
	        switch(name)
	        {  
	        case "First":  
	            System.out.println("Gaurav");  
	            break;  
	        case "Middle":  
	            System.out.println("Shivdas");  
	            break;  
	        case "Last":  
	            System.out.println("Chaudhari");
	        case "Fullname":
	        	System.out.println("Gaurav Shivdas chaudhari");
	        }  
	        
	}

}
