package day3Loop_for_while_case;

public class PrimeUsingWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		while (i<=50) {
			i++;
			if(i%i==0 && i/2==i) {
				System.out.println(i);
			}
				
			
		}
			
			
			
	}

}
