package day3Loop_for_while_case;

public class ForDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 //	for(int i=0;i<=10;i++)
		
	//	for(int i=10;i>0;i--)
		
		
		for(int i=1;i<=30;i++)
			
		{
			if(i%2==0 || i%3==0) {
			
			System.out.println(i);			
			}
		}
	}
}

