package day3Loop_for_while_case;

public class PrintOddUsingWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=100;
		while(i>0)
		{
			i--;
			if(i%2==1)
				System.out.println(i);
		}
	}

}	
