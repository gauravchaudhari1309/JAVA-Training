package day5Class2;

public class Test {

	public int getData1()
	{
	return 0;
	}
	public long getData()
	{
	return 1;
	}
	public static void main(String[] args)
	{
	Test obj = new Test();
	System.out.println(obj.getData1());
	}
}
