package day5Class2;

public class SalaryBased extends Teacher {
static int salary;

SalaryBased(int salary) {
	//super();
	this.salary = salary;
}

void salary() {
	
}


