package day5Class2;

public class Stud {

	String name;
	int age;
	String addr;
	
	void set_info(String name,int age){
		
	}
	
	void set_info(String name, int age, String addr){
		
		
	}
	
	public static void main(String[] args) {
		Stud s1= new Stud();
		s1.set_info("ABC", 23);
		s1.set_info("XYZ", 24, "NAshik");
	}
}
