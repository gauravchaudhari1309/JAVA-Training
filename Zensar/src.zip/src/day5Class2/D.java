package day5Class2;

import day5Class.A;

public class D extends A {
	
	public void method() {
		//using subclass accessible outside the package 
		System.out.println(c);
	}
}
