package day5Class2;

public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student();
		s1.doPublic();
		s1.doProtected();
		s1.doDefault();
		

	}

}
