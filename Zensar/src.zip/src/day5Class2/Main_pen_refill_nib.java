package day5Class2;

public class Main_pen_refill_nib {

	/*public static void main(String[] args) {
		Pen p1=new Pen();
		Nib tipNip= new Nib("Steel",0.5f);
		Refill refill=new Refill();
		
		
		refill.setInkColorString("Black");
		refill.setLength(10);
		refill.setTipNib(tip);
	
		p1.setRefill(refill);
		p1.setCapLength(5);
		p1.setBrandString("Flair");
	
		String brandString;
		
		brandString=p1.getBrandString();
		
		System.out.println("Brand "+brandString);
		System.out.println("cap length "+p1.getCapLength());
		System.out.println("Refill lenght "+(p1.getRefill().getLength()));
		System.out.println("Color"	+p1.getRefill().getInkColorString());
		
		String material=tipNib.getMaterialTypeString();
		float width= p1.getRefill().getTipNib().getWidth()
		
				System.out.println("Material "+tipNib.);
	}

*/
}