package day5Class2;

import day5Class.A;

public class E {
public static void main(String[] args) {
	A obj= new A();
	
	//System.out.println(obj.b);  //not accessible
	//System.out.println(obj.c); //not accessible
	System.out.println(obj.d);
}
}
