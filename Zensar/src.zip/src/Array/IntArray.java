package Array;



public class IntArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int intArr[]= {95,11,99,940,8};
		
		for(int i=0;i<intArr.length; i++)
			System.out.print(intArr[i]);
			
		
	}

}
