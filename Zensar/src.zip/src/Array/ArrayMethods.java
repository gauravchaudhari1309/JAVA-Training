package Array;

import java.util.Scanner;

public class ArrayMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* Scanner input = new Scanner(System.in);
		    double[] array2 = new double[10];
		    System.out.print("Enter 10 double values: ");

		    int i = 0;
		    while (i <array2.length) {
		      array2[i] = input.nextDouble();
		      i++;
		    }

		    System.out.println(average(array2));
		  }

		  public static int average(int[] array) {
		    int sum = 0;
		    for (int i = 0; i < array.length; i++) {
		      sum += array[i];
		    }
		    return sum / array.length;
		  }

		  public static double average(double[] array) {
		    double sum = 0;
		    for (int i = 0; i < array.length; i++) {
		      sum += array[i];
		    }
		    return sum / array.length;
*/		  }
	}


