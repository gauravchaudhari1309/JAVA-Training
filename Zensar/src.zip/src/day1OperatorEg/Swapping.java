package day1OperatorEg;

public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int x = 10;
	        int y = 5;
	        x = x + y;
	        y = x - y;
	        x = x - y;
	        System.out.println("After swaping: X is " +x+" & Y is " +y);
	}

}
