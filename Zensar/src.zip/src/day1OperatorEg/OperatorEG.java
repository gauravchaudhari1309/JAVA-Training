package day1OperatorEg;

public class OperatorEG {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 5, b=20;
		System.out.println(a++ + --b + --b + b/a + --a * b++);
		System.out.println("a ="+a+ " b="+b);
	}

}
