package day1OperatorEg;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 10;
		int b= 5;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
	}

}
