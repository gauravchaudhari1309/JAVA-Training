package day4Practical_PatternEg;
import java.util.Scanner;

public class Pattern_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		for(int line= 1; line<=3;line++)
		{
			for(int i=1;i<=5;i++)
			{
				System.out.print("*");
				
			}
			System.out.println();
		}
		sc.close();
	} 

}

 