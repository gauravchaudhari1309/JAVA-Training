package day4Practical_PatternEg;

public class AtoZusingFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(char i='A';i<='Z';i++)
		{
			System.out.print(" "+i);
		}
	}

}
