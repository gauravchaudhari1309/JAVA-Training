package day4Practical_PatternEg;

public class SquareOf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=20;i++)
		{
			int sq=i*i;
			System.out.println(sq);
		}
	}

}
