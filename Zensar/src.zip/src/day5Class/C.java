package day5Class;

public class C {

	public static void main(String[] args) {
		A ob=new A();
		//System.out.println(ob.a);
		System.out.println(ob.b);
		System.out.println(ob.c);
		System.out.println(ob.d);
	}
}
