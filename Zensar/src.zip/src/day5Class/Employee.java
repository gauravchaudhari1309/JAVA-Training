 package day5Class;

public class Employee {
	private int eid;
	private String empName;
	private int salary;
	
	public int getEid() {       
		return eid;
	}

	public void setEid(int eid) {  
		this.eid = eid;
	}

	public String getEmpName() {   
		return empName;
	}

	public void setEmpName(String empName) {  
		this.empName = empName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary=salary;
	}
}

	


