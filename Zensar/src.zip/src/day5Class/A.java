package day5Class;

public class A {

	public int  d = 0;
	private int a=5;
	int b= 10;
	protected int c=15;
	
	public A() {
		
	}
	}