package day5Class;

public class B extends A {

	B(){
		//System.out.println(a);   not accessible because private 
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}
