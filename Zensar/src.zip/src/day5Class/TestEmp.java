package day5Class;

public class TestEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee();
		 
		e.setEmpName("Bunty");
		e.setSalary(30000);
		 
		System.out.println(e.getEmpName());
		System.out.println(e.getSalary());
	}

}
